﻿using FirebaseAdmin;
using FirebaseAdmin.Messaging;
using Google.Apis.Auth.OAuth2;
using System;
using System.IO;
using System.Threading.Tasks;

namespace OceansOFMercyy.Services
{
    public class FirebaseMessagingService
    {
        public FirebaseMessagingService()
        {
            if (FirebaseApp.DefaultInstance == null)
            {
                FirebaseApp.Create(new AppOptions()
                {
                    Credential = GoogleCredential.FromFile("C:\\Users\\lab_services_student\\source\\repos\\OceansOFMercyy\\wwwroot\\oceansofmercy-cbab6-firebase-adminsdk-s41x0-02c5d048e4.json")
                });
            }
        }

        public async Task<string> SendNotificationToTopicAsync(string topic, string title, string content)
        {
            var message = new Message()
            {
                Notification = new Notification()
                {
                    Title = title,
                    Body = content
                },
                Topic = topic
            };

            string response = await FirebaseMessaging.DefaultInstance.SendAsync(message);
            return response;
        }

    }
}
