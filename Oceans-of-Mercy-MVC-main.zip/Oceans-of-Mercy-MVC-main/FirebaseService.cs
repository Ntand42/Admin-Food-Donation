﻿using FirebaseAdmin;
using FirebaseAdmin.Messaging;
using Google.Apis.Auth.OAuth2;
using Google.Cloud.Firestore;
using Microsoft.AspNet.SignalR;
using OceansOFMercyy.Models;

namespace OceansOFMercyy.Services
{
    public class FirebaseService
    {
        private readonly FirestoreDb _firestoreDb;

        public FirebaseService()
        {
        }

        public FirebaseService(string credentialsPath)
        {
            if (FirebaseApp.DefaultInstance == null)
            {
                FirebaseApp.Create(new AppOptions
                {
                    Credential = GoogleCredential.FromFile(credentialsPath)
                });
            }

            // Initialize FirestoreDb
            _firestoreDb = FirestoreDb.Create(FirebaseApp.DefaultInstance.Options.ProjectId);
        }

        public void ListenForPickupRequests()
        {
            CollectionReference pickupRequestsRef = _firestoreDb.Collection("donations");
            var hubContext = GlobalHost.ConnectionManager.GetHubContext<NotificationHub>();

            pickupRequestsRef.Listen(snapshot =>
            {
                foreach (var change in snapshot.Changes)
                {
                    if (change.ChangeType == DocumentChange.Type.Added)
                    {
                        var request = change.Document.ToDictionary();
                       string message = $"New Pickup Request: {request["actionType"]}, " +
                       $"Donation Date: {request["donationDate"]}, " +
                        $"Product Name: {request["productName"]}, " +
                        $"Quantity: {request["quantity"]}";
                        hubContext.Clients.All.receiveNotification(message);
                    }
                }
            });
        }

        public async Task AddNews(string title, string timestamp, string content)
        {
            try
            {
                var news = new
                {
                    Title = title,
                    Content = content,
                    Timestamp = timestamp
                };

                var collectionRef = _firestoreDb.Collection("news");
                await collectionRef.AddAsync(news); // Add document to Firestore collection

                Console.WriteLine("News added to Firebase successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error adding news: {ex.Message}");
            }
        }


    }
}
