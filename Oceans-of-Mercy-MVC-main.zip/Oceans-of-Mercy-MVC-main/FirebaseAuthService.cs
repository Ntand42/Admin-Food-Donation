﻿using FirebaseAdmin.Auth;

namespace OceansOFMercyy
{
    public class FirebaseAuthService
    {
        private readonly FirebaseAuth _firebaseAuth;

        public FirebaseAuthService()
        {
            _firebaseAuth = FirebaseAuth.DefaultInstance;
        }

        public FirebaseAuth GetFirebaseAuth()
        {
            return _firebaseAuth;
        }
    }
}
