﻿using Google.Cloud.Firestore;
using Google.Apis.Auth.OAuth2;
using Grpc.Auth;
using Google.Cloud.Firestore.V1;
using OceansOFMercyy.Models;
using FirebaseAdmin.Messaging;

namespace OceansOFMercyy.Services
{
    public class FirestoreService
    {
        private readonly FirestoreDb _db;

        public FirestoreService(string projectId, string serviceAccountPath)
        {
            // Load credentials from the service account JSON file
            GoogleCredential credential = GoogleCredential.FromFile(serviceAccountPath);
            var firestoreClient = new FirestoreClientBuilder
            {
                Credential = credential
            }.Build();

            // Initialize FirestoreDb instance
            _db = FirestoreDb.Create(projectId, firestoreClient);
        }

      
        public FirestoreDb GetDb()
        {
            return _db;
        }

        public async Task<List<Dictionary<string, object>>> GetUsersAsync()
        {
            CollectionReference usersRef = _db.Collection("users");
            QuerySnapshot snapshot = await usersRef.GetSnapshotAsync();

            var users = new List<Dictionary<string, object>>();
            foreach (DocumentSnapshot document in snapshot.Documents)
            {
                users.Add(document.ToDictionary());
            }
            return users;
        }

        public async Task AddUserAsync(User user)
        {
            var collection = _db.Collection("users");

            var userData = new Dictionary<string, object>
            {
               { "name", user.name },
               { "surname", user.surname },
               { "contact", user.contact },
               { "email", user.Email }
            };

            await collection.AddAsync(userData);
        }


        public async Task<List<Driver>> GetDriversAsync()
        {
            CollectionReference driversRef = _db.Collection("drivers");
            QuerySnapshot snapshot = await driversRef.GetSnapshotAsync();

            var drivers = new List<Driver>();
            foreach (var document in snapshot.Documents)
            {
                drivers.Add(document.ConvertTo<Driver>());
            }
            return drivers;
        }


        // Add a new driver

        public async Task AddDriverAsync(Driver driver)
        {
            CollectionReference driversRef = _db.Collection("drivers");
            await driversRef.AddAsync(driver);
        }

        //Update Driver
        

        public async Task<List<Dictionary<string, object>>> GetDonationsAsync()
        {
            CollectionReference donationsRef = _db.Collection("donations");
            QuerySnapshot snapshot = await donationsRef.GetSnapshotAsync();

            var donations = new List<Dictionary<string, object>>();
            foreach (DocumentSnapshot document in snapshot.Documents)
            {
                donations.Add(document.ToDictionary());
            }
            return donations;
        }

        // Method to get livestock donations
        public async Task<List<Dictionary<string, object>>> GetLiveStockDonationAsync()
        {
            CollectionReference livestockdonationRef = _db.Collection("livestockdonation");
            QuerySnapshot snapshot = await livestockdonationRef.GetSnapshotAsync();

            var livestockdonation = new List<Dictionary<string, object>>();

            foreach (DocumentSnapshot document in snapshot.Documents)
            {
                livestockdonation.Add(document.ToDictionary());
            }

            return livestockdonation;
        }

        public async Task<List<Dictionary<string, object>>> GetNewsAsync()
        {
            var newsCollection = _db.Collection("news");
            var snapshot = await newsCollection.GetSnapshotAsync();
            var newsData = snapshot.Documents.Select(doc => doc.ToDictionary()).ToList();
            return newsData;
        }

        // Add news to Firestore
        public async Task AddNewsAsync(News news)
        {
            var newsCollection = _db.Collection("news");
            var newsDocument = newsCollection.Document();

            // Set news document data
            await newsDocument.SetAsync(new
            {
                title = news.Title,
                content = news.Content,
                author = news.Author,
                timestamp = Timestamp.FromDateTime(news.timestamp) // Convert DateTime to Firestore Timestamp
            });
        }

    }


}
