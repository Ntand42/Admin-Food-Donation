using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;
using Microsoft.AspNetCore.Authentication.Cookies;
using OceansOFMercyy.Services;

namespace OceansOFMercyy
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            builder.Services.AddControllersWithViews();

            // Path to the Firebase service account key file
            var serviceAccountPath = Path.Combine(builder.Environment.ContentRootPath, "wwwroot/oceansofmercy-cbab6-firebase-adminsdk-s41x0-02c5d048e4.json");

            // Initialize Firebase App
            FirebaseApp.Create(new AppOptions
            {
                Credential = GoogleCredential.FromFile(serviceAccountPath)
            });

            // Firebase Project ID
            string firebaseProjectId = "oceansofmercy-cbab6";

            // Register Firebase Services
            builder.Services.AddSingleton<FirebaseService>(provider => new FirebaseService(serviceAccountPath));
            builder.Services.AddSingleton<FirestoreService>(provider => new FirestoreService(firebaseProjectId, serviceAccountPath));
            builder.Services.AddSingleton<FirebaseAuthService>();
            builder.Services.AddSingleton<RealtimeDatabaseService>();

            // Add Session Services
            builder.Services.AddDistributedMemoryCache();
            builder.Services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(30); // Set session timeout
                options.Cookie.HttpOnly = true; // Enhance security
                options.Cookie.IsEssential = true;
            });

            // Add Authentication
            builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(options =>
                {
                    options.LoginPath = "/Account/Login";
                    options.LogoutPath = "/Account/Logout";
                    options.AccessDeniedPath = "/Account/AccessDenied";
                });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthentication(); 
            app.UseAuthorization();

            app.UseSession(); // Enable session handling

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
