﻿using Google.Cloud.Firestore;
using Microsoft.AspNetCore.Mvc;
using OceansOFMercyy.Models;
using OceansOFMercyy.Services;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static Google.Rpc.Context.AttributeContext.Types;

namespace OceansOFMercyy.Controllers
{
    public class NewsController : Controller
    {
        private readonly FirestoreService _firestoreService;

        // Constructor to inject FirestoreService
        public NewsController(FirestoreService firestoreService)
        {
            _firestoreService = firestoreService;
        }

        // GET: News/Index - Display all news
        public async Task<IActionResult> Index()
        {
            var newsData = await _firestoreService.GetNewsAsync();
            var newsList = newsData.Select(data => new News
            {
                Title = data.ContainsKey("title") ? data["title"].ToString() : "",
                Content = data.ContainsKey("content") ? data["content"].ToString() : "",
                Author = data.ContainsKey("author") ? data["author"].ToString() : "",
                timestamp = data.ContainsKey("timestamp") && data["timestamp"] is Google.Cloud.Firestore.Timestamp timestamp
                    ? timestamp.ToDateTime()
                    : DateTime.UtcNow // Default to current UTC time if conversion fails
            }).ToList();

            return View(newsList);
        }


        // GET: News/Create - Show the form to create news
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: News/Create - Handle form submission to add news
        [HttpPost]
        public async Task<IActionResult> Create(string title, string content, string author)
        {
            if (string.IsNullOrEmpty(title) || string.IsNullOrEmpty(content) || string.IsNullOrEmpty(author))
            {
                ViewBag.Message = "Title and Content are required.";
                ViewBag.MessageClass = "error";
                return View();
            }

            try
            {
                var news = new News
                {
                    Title = title,
                    Content = content,
                    Author = author,
                    timestamp = DateTime.UtcNow // Set the timestamp
                };

                // Call the FirestoreService to add the news to Firestore
                await _firestoreService.AddNewsAsync(news);

                ViewBag.Message = "News added successfully!";
                ViewBag.MessageClass = "success";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"Failed to add news: {ex.Message}";
                ViewBag.MessageClass = "error";
                return View();
            }
        }
    }
}