﻿using Microsoft.AspNetCore.Mvc;
using OceansOFMercyy.Services;
using OceansOFMercyy.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace OceansOFMercyy.Controllers
{
    public class DonationsController : Controller
    {
        private readonly FirestoreService _firestoreService;

        public DonationsController(FirestoreService firestoreService)
        {
            _firestoreService = firestoreService;
        }

        public async Task<IActionResult> Index()
        {
            var donationsData = await _firestoreService.GetDonationsAsync();

            // Convert Firestore data to Donation model
            var donations = donationsData.Select(d => new Donation
            {
                productName = d.ContainsKey("productName") ? d["productName"].ToString() : "",
                bestBeforeDate = d.ContainsKey("bestBeforeDate") ? d["bestBeforeDate"].ToString() : "" ,
                perishability = d.ContainsKey("perishability") ? d["perishability"].ToString() : "",
                quantity = d.ContainsKey("quantity") ? d["quantity"].ToString() : "",
                donationDate = d.ContainsKey("donationDate") ? d["donationDate"].ToString(): "" ,
                actionType = d.ContainsKey("actionType") ? d["actionType"].ToString() : "",

            }).ToList();

            return View(donations);
        }
    }
}
