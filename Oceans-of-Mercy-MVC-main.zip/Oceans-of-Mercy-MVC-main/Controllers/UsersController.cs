﻿using Google.Cloud.Firestore;
using Microsoft.AspNetCore.Mvc;
using OceansOFMercyy.Models;
using OceansOFMercyy.Services;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OceansOFMercyy.Controllers
{
    public class UsersController : Controller
    {
        private readonly FirestoreService _firestoreService;

        public UsersController(FirestoreService firestoreService)
        {
            _firestoreService = firestoreService;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            
            services.AddSingleton<FirestoreDb>(FirestoreDb.Create("yoceansofmercy-cbab6-firebase-adminsdk-s41x0-02c5d048e4.json"));
            services.AddScoped<FirestoreService>();
            services.AddControllersWithViews();
        }

        // Fetch and display all users
        public async Task<IActionResult> Index()
        {
            var usersData = await _firestoreService.GetUsersAsync();
            var users = usersData.Select(data => new User
            {
                name = data.ContainsKey("name") ? data["name"].ToString() : "",
                contact = data.ContainsKey("contact") ? data["contact"].ToString() : "",
                surname = data.ContainsKey("surname") ? data["surname"].ToString() : "",
                Email = data.ContainsKey("email") ? data["email"].ToString() : ""
            }).ToList();

            ViewBag.NewUser = new User();
            return View(users);
        }

        // Handle the form submission for adding a new user
        [HttpPost]
        public async Task<IActionResult> AddUser(User user)
        {
            if (ModelState.IsValid)
            {
                await _firestoreService.AddUserAsync(user);
                return RedirectToAction(nameof(Index));
            }

            
            var usersData = await _firestoreService.GetUsersAsync();
            var users = usersData.Select(data => new User
            {
                name = data.ContainsKey("name") ? data["name"].ToString() : "",
                contact = data.ContainsKey("contact") ? data["contact"].ToString() : "",
                surname = data.ContainsKey("surname") ? data["surname"].ToString() : "",
                Email = data.ContainsKey("email") ? data["email"].ToString() : ""
            }).ToList();

            ViewBag.NewUser = user; 
            return View("Index", users);
        }

       

      




    }
}
