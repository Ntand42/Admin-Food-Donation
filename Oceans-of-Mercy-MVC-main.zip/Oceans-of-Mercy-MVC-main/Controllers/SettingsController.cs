﻿using System.Security.Cryptography;
using Microsoft.AspNetCore.Mvc;
using System.Text;

namespace OceansOFMercyy.Controllers
{
    public class SettingsController : Controller
    {

        public IActionResult Index()
        {
           
            string usernamee = "admin";
            string password = "password"; 

           
            string hashedPassword = HashPassword(password);

            
            ViewData["AdminEmail"] = usernamee;
            ViewData["HashedPassword"] = hashedPassword;
            ViewData["EmailNotification"] = true; 
            ViewData["ThemeMode"] = "Light"; 

            return View();
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
