﻿using Microsoft.AspNetCore.Mvc;
using OceansOFMercyy.Models;

namespace OceansOFMercyy.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // POST: Account/Login
        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            
            const string adminUsername = "admin";
            const string adminPassword = "password";

            if (username == adminUsername && password == adminPassword)
            {
                HttpContext.Session.SetString("AdminLoggedIn", "true");
                return RedirectToAction("Index", "Home"); // Redirect to Users page
            }

            ViewBag.ErrorMessage = "Invalid username or password.";
            return View();
        }

        // GET: Account/Logout
        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("AdminLoggedIn");
            return RedirectToAction("Login");
        }
    }

}

