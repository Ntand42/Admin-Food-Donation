﻿using Microsoft.AspNetCore.Mvc;
using OceansOFMercyy.Models;
using OceansOFMercyy.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OceansOFMercyy.Controllers
{
    public class DriversController : Controller
    {
        private readonly FirestoreService _firestoreService;

        public DriversController(FirestoreService firestoreService)
        {
            _firestoreService = firestoreService;
        }

        // Display list of drivers
        public async Task<IActionResult> Index()
        {
            List<Driver> drivers = await _firestoreService.GetDriversAsync();
            return View(drivers);
        }

        // Handle form submission to add a new driver
        [HttpPost]
        public async Task<IActionResult> AddDriver(Driver newDriver)
        {
            if (ModelState.IsValid)
            {
                await _firestoreService.AddDriverAsync(newDriver);
            }

            return RedirectToAction("Index");
        }
    }

}