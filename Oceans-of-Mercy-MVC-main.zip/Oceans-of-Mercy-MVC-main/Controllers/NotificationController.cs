﻿using Microsoft.AspNetCore.Mvc;
using OceansOFMercyy.Models;
using OceansOFMercyy.Services;
using System.Threading.Tasks;


namespace OceansOFMercyy.Controllers
{
    public class NotificationsController : Controller
    {
        private readonly FirebaseMessagingService _firebaseService;

        public NotificationsController()
        {
            _firebaseService = new FirebaseMessagingService();
        }


        [HttpPost]
        public async Task<ActionResult> SendNotification(Notifications notifications)
        {
            if (ModelState.IsValid)
            {
                var response = await _firebaseService.SendNotificationToTopicAsync("news_updates", notifications.Title, notifications.Description);
                ViewBag.Message = $"Notification sent successfully. Response: {response}";
                return View("Index");
            }

            return View("Error");
        }

           
            

        public ActionResult Index()
        {
            return View();
        }
    }
}