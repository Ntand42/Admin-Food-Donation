﻿using Microsoft.AspNetCore.Mvc;
using OceansOFMercyy.Services;
using OceansOFMercyy.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OceansOFMercyy.Controllers
{
    public class LivestockDonationController : Controller
    {
        private readonly FirestoreService _firestoreService;

        public LivestockDonationController(FirestoreService firestoreService)
        {
            _firestoreService = firestoreService;
        }

        public async Task<IActionResult> Index()
        {
            var livestockdonationData = await _firestoreService.GetLiveStockDonationAsync();

            var livestockdonations = livestockdonationData.Select(d => new LivestockDonation
            {
                email = d.ContainsKey("email") ? d["email"].ToString() : "",
                livestockType = d.ContainsKey("livestockType") ? d["livestockType"].ToString() : "",
                weight = d.ContainsKey("weight") ? d["weight"].ToString() : "",
                age = d.ContainsKey("age") ? d["age"].ToString() : "",
                quantity = d.ContainsKey("quantity") ? d["quantity"].ToString() : ""
            }).ToList();

            return View(livestockdonations);
        }
    }
}
