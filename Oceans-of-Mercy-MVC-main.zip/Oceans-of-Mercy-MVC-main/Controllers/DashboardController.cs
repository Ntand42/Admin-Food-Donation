﻿using Microsoft.AspNetCore.Mvc;

namespace OceansOFMercyy.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("IsAuthenticated") != "true")
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
        }
    }
}
