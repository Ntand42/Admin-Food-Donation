﻿using Microsoft.AspNetCore.Mvc;

namespace OceansOFMercyy.Controllers
{
    public class AnalyticsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
