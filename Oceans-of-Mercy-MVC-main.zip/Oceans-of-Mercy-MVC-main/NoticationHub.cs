﻿using Microsoft.AspNet.SignalR;


public class NotificationHub : Hub
{
    public void NotifyAdmin(string message)
    {
        Clients.All.receiveNotification(message);
    }
}
