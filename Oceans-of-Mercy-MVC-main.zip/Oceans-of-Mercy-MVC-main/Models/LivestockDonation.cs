﻿using Google.Cloud.Firestore;

namespace OceansOFMercyy.Models
{
    [FirestoreData]
    public class LivestockDonation
    {
       
        [FirestoreProperty]
        public string email { get; set; }

        [FirestoreProperty]
        public string livestockType { get; set; }

        [FirestoreProperty]
        public string weight { get; set; }

        [FirestoreProperty]
        public string age { get; set; }

        [FirestoreProperty]
        public string quantity { get; set; }



    }
}
