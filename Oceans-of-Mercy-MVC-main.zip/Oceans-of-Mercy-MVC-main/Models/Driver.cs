﻿using Google.Cloud.Firestore;

namespace OceansOFMercyy.Models
{

    [FirestoreData]
    public class Driver
    {
     
        [FirestoreProperty]
        public string Name { get; set; }

        [FirestoreProperty]
        public string ContactInfo { get; set; }

        [FirestoreProperty]
        public string Vehicle { get; set; }

        [FirestoreProperty]
        public string Status { get; set; } 
    }
}
