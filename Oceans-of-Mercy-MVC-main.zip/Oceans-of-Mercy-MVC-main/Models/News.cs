﻿namespace OceansOFMercyy.Models
{
    public class News
    {
        public string id { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
        public DateTime timestamp { get; set; }
    }
}
