﻿using Google.Cloud.Firestore;
using System.ComponentModel.DataAnnotations;

namespace OceansOFMercyy.Models
{

    [FirestoreData]
    public class User
    {

        public string name { get; set; } 
        public string contact { get; set; } 
        public string surname { get; set; }  
     
        public string Email { get; set; }
       

      
    }
}

