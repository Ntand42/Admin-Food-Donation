﻿using Google.Cloud.Firestore;

namespace OceansOFMercyy.Models
{
    [FirestoreData]
    public class Donation
    {
        [FirestoreProperty]

        public int userId { get; set; }    
        public string productName { get; set; }

        [FirestoreProperty]
        public string bestBeforeDate { get; set; }

        [FirestoreProperty]
        public string perishability { get; set; }

        [FirestoreProperty]
        public string quantity { get; set; }

        [FirestoreProperty]
        public string donationDate { get; set; } 

        [FirestoreProperty]
        public string actionType { get; set; } 



    }


}
