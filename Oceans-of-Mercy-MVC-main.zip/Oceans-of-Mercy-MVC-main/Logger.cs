﻿namespace OceansOFMercyy.Services
{
    internal class Logger
    {
    }
}