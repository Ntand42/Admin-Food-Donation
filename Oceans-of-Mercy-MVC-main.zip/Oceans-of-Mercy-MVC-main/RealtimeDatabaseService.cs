﻿using Newtonsoft.Json.Linq;

namespace OceansOFMercyy
{
    public class RealtimeDatabaseService
    {
        private readonly string _databaseUrl = "https://console.firebase.google.com/project/oceansofmercy-cbab6/database/oceansofmercy-cbab6-default-rtdb/data/~2F";
        private readonly HttpClient _httpClient;

        public RealtimeDatabaseService()
        {
            _httpClient = new HttpClient();
        }

        public async Task<string> GetUserDataAsync(string userId)
        {
            string url = $"{_databaseUrl}/users/{userId}.json";

            HttpResponseMessage response = await _httpClient.GetAsync(url);
            response.EnsureSuccessStatusCode();

            string json = await response.Content.ReadAsStringAsync();
            JObject data = JObject.Parse(json);

            return data.ToString();
        }
    }
}
